using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_CalculadoraConsola
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1 = 0, num2 = 0, resultado;
            bool validaNum1, validaNum2, validaOp;


            // validação do numero1

            validaNum1 = false;
            while (validaNum1 == false)
            {
                Console.WriteLine("Insira o primeiro numero");
                var aux = Console.ReadLine();
                validaNum1 = Int32.TryParse(aux, out num1);

                if (validaNum1 == false)
                {
                    Console.WriteLine("O {0} não é um numero", aux);
                    //Console.WriteLine("O " + aux + " não é um numero");
                }
            }

            // validação do nuemro2
            do
            {
                Console.WriteLine("Insira o segundo numero");
                var aux = Console.ReadLine();
                validaNum2 = Int32.TryParse(aux, out num2);

                if (validaNum2 == false)
                {
                    Console.WriteLine("O {0} não é um numero", aux);
                    //Console.WriteLine("O " + aux + " não é um numero");
                }
            } while (validaNum2 == false);


            //valida e realiza operação
            do
            {
                Console.WriteLine("escolha a operação a realizar\n");
                Console.WriteLine("\t para somar escolha '+'\n\t para subtrair escolha '-'\n");
                var op = Console.ReadLine();

                switch (op)
                {
                    case "+":
                        resultado = num1 + num2;
                        Console.WriteLine(num1 + op + num2 + " = " + resultado);
                        validaOp = true;
                        break;
                    case "-":
                        resultado = num1 - num2;
                        Console.WriteLine(num1 + op + num2 + " = " + resultado);
                        validaOp = true;
                        break;
                    default:
                        Console.WriteLine("operação invalida");
                        validaOp = false;
                        break;

                }
            } while (validaOp == false);
            //Console.WriteLine(num1 + op + num2); //teste funcionalidade
            //Console.WriteLine(num2); //teste funcionalidade
            //Console.WriteLine(validaNum1); //teste funcionalidade
            Console.ReadKey();

            
        }
    }
}
